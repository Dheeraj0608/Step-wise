"""FastAPI backend for the Stepwise dashboard.

Serves the single-page front end from ``static/`` and a small read-only JSON
API over whatever result files are in ``results/``. The front end is the
Stepwise design wired to this API — it does no computation of its own, so
every number on screen comes from :mod:`stepwise.score`.

Run it with::

    python main.py dashboard
    # or: uvicorn stepwise.dashboard.app:app --reload
"""

from __future__ import annotations

import json
import math
from functools import lru_cache
from pathlib import Path

from fastapi import Body, FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from .. import score
from ..agent.chat import SESSIONS, stream_reply
from ..agent.tools import AnalysisContext
from ..config import (
    ALL_INTERVENTION_TYPES,
    ANALYST_MODEL,
    DATASETS,
    LABELS,
    PERTURBATION_TYPES,
    RESULTS_DIR,
    api_key,
)
from ..llm import LLMError
from ..pipeline import load_records, load_traces

STATIC_DIR = Path(__file__).parent / "static"

app = FastAPI(title="Stepwise", description="CoT faithfulness dashboard", version="0.1.0")


# --------------------------------------------------------------------------
# Loading
# --------------------------------------------------------------------------


def _run_path(run: str) -> Path:
    """Resolve a run name to a results file, refusing paths outside results/."""
    name = Path(run).name  # strip any directory component
    if not name.endswith(".jsonl"):
        name = f"{name}.jsonl"
    path = RESULTS_DIR / name
    if not path.exists():
        raise HTTPException(404, f"no run named {run!r}; try /api/runs")
    return path


@lru_cache(maxsize=8)
def _cached_payload(path_str: str, mtime: float) -> dict:
    """Parse a results file once per modification.

    ``mtime`` is part of the key rather than something checked inside, so a
    rerun of the pipeline invalidates the cache for free.
    """
    path = Path(path_str)
    records = load_records(path)
    frame = score.records_dataframe(records)
    traces = load_traces(path).get("traces", {})
    return {"frame": frame, "traces": traces, "records": records}


def _load(run: str) -> dict:
    path = _run_path(run)
    return _cached_payload(str(path), path.stat().st_mtime)


def _filtered(frame, **filters):
    for column, value in filters.items():
        if value in (None, "", "all") or column not in frame.columns:
            continue
        frame = frame[frame[column] == value]
    return frame


def _json_safe(value):
    """Replace NaN and infinity with None, recursively.

    pandas reports "no data" as NaN. Accuracy retained, for one, is NaN for a
    group where the model got every question wrong at baseline, since there
    is nothing to retain. NaN is not valid JSON, so the encoder rejects the
    whole response. The simulated demo never produced one; the first real run
    did, and /api/summary returned a 500 that left the dashboard blank.
    """
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    return value


# --------------------------------------------------------------------------
# API
# --------------------------------------------------------------------------


@app.get("/api/runs")
def list_runs() -> dict:
    """Every results file on disk: real runs first, newest first within each."""
    # Sidecar files (<run>.battery.jsonl, .mech.jsonl, .judge.jsonl) also match
    # *.jsonl but are not runs in their own right — exclude them so they do not
    # appear as phantom runs in the picker.
    SIDECARS = (".battery", ".mech", ".judge", ".patch", ".introspect", ".mech_behav",
                ".interactions")
    runs = []
    for path in sorted(RESULTS_DIR.glob("*.jsonl"), key=lambda p: -p.stat().st_mtime):
        if any(path.stem.endswith(s) for s in SIDECARS):
            continue
        sidecar = path.with_suffix(".traces.json")
        meta = {}
        if sidecar.exists():
            try:
                payload = json.loads(sidecar.read_text(encoding="utf-8"))
                meta = {
                    "models": payload.get("models", []),
                    "duration_s": payload.get("duration_s"),
                    "simulated": bool(payload.get("simulated")),
                }
            except json.JSONDecodeError:
                pass
        runs.append(
            {
                "name": path.stem,
                "records": sum(1 for _ in path.open(encoding="utf-8")),
                "modified": path.stat().st_mtime,
                "has_analysis": (RESULTS_DIR / f"analysis_{path.stem}.md").exists(),
                **meta,
            }
        )
    # Real runs first, newest first within each group. A simulated demo must
    # never be what the dashboard opens on while real results exist, even if
    # the demo was generated more recently.
    runs.sort(key=lambda r: (bool(r.get("simulated")), -r["modified"]))
    return {"runs": runs, "labels": list(LABELS),
            "perturbation_types": list(ALL_INTERVENTION_TYPES),
            # The CLI's --dataset takes a task family, not a run name. The page
            # needs to know which is which: a run called "demo" or one saved
            # under a custom --output is not a dataset, so the commands it
            # suggests for that run have to name a real dataset and redirect
            # their output, or they exit with "Unknown dataset".
            "datasets": list(DATASETS)}


@app.get("/api/summary")
def summary(run: str = Query(..., description="run name, e.g. 'gsm8k'")) -> dict:
    """Everything the dashboard's charts need, in one payload."""
    data = _load(run)
    frame = data["frame"]
    if frame.empty:
        return {"run": run, "empty": True}
    sidecar = load_traces(_run_path(run))
    payload = score.summary(frame)
    payload.update(
        {
            "run": run,
            "empty": False,
            "simulated": bool(sidecar.get("simulated")),
            "warning": sidecar.get("warning"),
            "models": sorted(frame["model_name"].dropna().unique().tolist()),
            "datasets": sorted(frame["dataset"].dropna().unique().tolist()),
            "perturbation_types": [
                t for t in PERTURBATION_TYPES
                if t in set(frame["perturbation_type"].dropna())
            ],
            "labels": list(LABELS),
        }
    )
    return JSONResponse(_json_safe(json.loads(json.dumps(payload, default=str))))


@app.get("/api/grid")
def grid(
    run: str,
    model: str = "all",
    dataset: str = "all",
    metric: str = "faithfulness",
) -> dict:
    """The per-step dependency grid: rows are question x step, columns class.

    This is the drill-down heatmap from the design — one cell per
    intervention, coloured by its label, rather than an aggregate.
    """
    frame = _filtered(_load(run)["frame"], model_name=model, dataset=dataset)
    if frame.empty:
        return {"rows": [], "types": list(PERTURBATION_TYPES)}

    types = [t for t in PERTURBATION_TYPES if t in set(frame["perturbation_type"])]
    rows = []
    for (question_id, step_idx), group in frame.groupby(["question_id", "step_idx"]):
        by_type = {r["perturbation_type"]: r for r in group.to_dict("records")}
        rows.append(
            {
                "question_id": question_id,
                "step_idx": int(step_idx),
                "n_steps": int(group["n_steps"].max()),
                "label": f"{question_id.split('-')[-1]} · s{int(step_idx)}",
                "cells": [
                    {
                        "type": t,
                        "label": (by_type.get(t) or {}).get("label") or None,
                        "model": (by_type.get(t) or {}).get("model_name"),
                        "title": _cell_title(by_type.get(t), t),
                    }
                    for t in types
                ],
            }
        )
    rows.sort(key=lambda r: (r["question_id"], r["step_idx"]))
    return {"rows": rows[:400], "types": types, "total_rows": len(rows)}


def _cell_title(record: dict | None, ptype: str) -> str:
    if not record:
        return f"{ptype}: not run"
    label = record.get("label") or "unscored"
    return (
        f"{ptype} · {label}\n"
        f"{record.get('original_answer')} -> {record.get('perturbed_answer')}"
    )


@app.get("/api/records")
def records(
    run: str,
    model: str = "all",
    dataset: str = "all",
    perturbation_type: str = "all",
    label: str = "all",
    limit: int = 50,
    offset: int = 0,
) -> dict:
    """Paged drill-down rows for the examples table."""
    frame = _filtered(
        _load(run)["frame"],
        model_name=model,
        dataset=dataset,
        perturbation_type=perturbation_type,
        label=label,
    )
    columns = [
        "question_id", "model_name", "dataset", "step_idx", "n_steps",
        "perturbation_type", "label", "original_answer", "perturbed_answer",
        "gold_answer", "original_step", "perturbed_step", "perturbation_method",
        "original_correct",
    ]
    available = [c for c in columns if c in frame.columns]
    limit = max(1, min(int(limit), 200))
    page = frame[available].iloc[offset : offset + limit]
    return {
        "total": int(len(frame)),
        "offset": offset,
        "limit": limit,
        "rows": json.loads(page.to_json(orient="records")),
    }


@app.get("/api/example")
def example(
    run: str,
    question_id: str,
    model: str,
    step_idx: int,
    perturbation_type: str,
) -> dict:
    """One cell in full: the original and perturbed traces, side by side."""
    data = _load(run)
    frame = _filtered(
        data["frame"],
        question_id=question_id,
        model_name=model,
        step_idx=step_idx,
        perturbation_type=perturbation_type,
    )
    if frame.empty:
        raise HTTPException(404, "no such cell")
    record = json.loads(frame.iloc[[0]].to_json(orient="records"))[0]
    trace = data["traces"].get(f"{question_id}|{model}", {})
    steps = trace.get("steps", [])
    return {
        "question": trace.get("question", ""),
        "gold_answer": trace.get("gold_answer", record.get("gold_answer")),
        "answer_type": trace.get("answer_type", record.get("answer_type")),
        "original": {
            "answer": record.get("original_answer"),
            "correct": bool(record.get("original_correct")),
            "steps": steps,
        },
        "perturbed": {
            "answer": record.get("perturbed_answer"),
            "correct": bool(record.get("perturbed_correct")),
            "steps": [
                {
                    "index": s.get("index"),
                    "marker": s.get("marker", ""),
                    "text": (
                        record.get("perturbed_step")
                        if s.get("index") == step_idx
                        else s.get("text")
                    ),
                    "was": s.get("text") if s.get("index") == step_idx else None,
                    "changed": s.get("index") == step_idx,
                }
                for s in steps
            ],
        },
        "label": record.get("label"),
        "perturbation_type": perturbation_type,
        "perturbation_method": record.get("perturbation_method"),
        "step_idx": step_idx,
        "model": model,
    }


@app.get("/api/analysis")
def analysis(run: str) -> dict:
    """The agent's written analysis for a run, if one has been produced."""
    path = RESULTS_DIR / f"analysis_{run}.md"
    if not path.exists():
        return {"exists": False, "run": run}
    transcript_path = path.with_suffix(".json")
    transcript = {}
    if transcript_path.exists():
        try:
            transcript = json.loads(transcript_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            transcript = {}
    return {
        "exists": True,
        "run": run,
        "report": path.read_text(encoding="utf-8"),
        "model": transcript.get("model", ""),
        "turns": transcript.get("turns", 0),
        "tool_calls": transcript.get("tool_calls", []),
    }


# --------------------------------------------------------------------------
# Agentic chat
# --------------------------------------------------------------------------


def _context_for(run: str) -> AnalysisContext:
    data = _load(run)
    return AnalysisContext(
        frame=data["frame"], traces=data["traces"], dataset=run
    )


@app.get("/api/chat/status")
def chat_status() -> dict:
    """Whether chat can run at all, so the UI can explain itself."""
    model = ANALYST_MODEL
    from ..config import resolve_model

    spec = resolve_model(model)
    return {
        "available": bool(api_key(spec.provider)),
        # The server has no key, but the UI can still offer chat if the visitor
        # pastes their own — the safe mode for a public deploy.
        "accepts_byo_key": True,
        "model": spec.display,
        "provider": spec.provider,
        "requires": {
            "groq": "GROQ_API_KEY",
            "openai": "OPENAI_API_KEY",
            "anthropic": "ANTHROPIC_API_KEY",
        }.get(spec.provider, spec.provider.upper()),
        "sessions": len(SESSIONS),
    }


@app.post("/api/chat")
def chat(
    run: str = Body(...),
    message: str = Body(...),
    session_id: str | None = Body(None),
    model: str | None = Body(None),
    api_key: str | None = Body(None),
) -> StreamingResponse:
    """Answer a question about a run, streaming the agent's work as SSE.

    Each event is one line of ``data: {json}``. The agent decides its own
    tool calls; the client renders them as they arrive, which is what makes
    the loop legible rather than a spinner.

    ``api_key`` is the bring-your-own-key path: if supplied it is used only for
    this request's client and never persisted, so a public deploy can leave
    chat on without spending the host's quota. If it is absent the server's own
    environment key is used (the local-dashboard case).
    """
    from ..config import resolve_model as _resolve
    from ..llm import LLMClient as _LLMClient

    message = (message or "").strip()
    if not message:
        raise HTTPException(400, "message is empty")
    if len(message) > 4000:
        raise HTTPException(400, "message too long")

    ctx = _context_for(run)  # raises 404 for an unknown run before streaming
    if ctx.frame.empty:
        raise HTTPException(400, f"run {run!r} has no records to talk about")

    chosen = model or ANALYST_MODEL
    spec = _resolve(chosen)
    byo = (api_key or "").strip()
    # A visitor's own key is used for this request only and never persisted. If
    # none is given, the server's own environment key is used (local case); when
    # neither exists, stream_reply raises and the client is told over the stream,
    # and the UI already learns to offer a key box from /api/chat/status.
    client = _LLMClient(api_keys={spec.provider: byo}) if byo else None

    session = SESSIONS.get_or_create(session_id, run, ctx, chosen)

    def sse(payload: dict) -> str:
        """One SSE frame. The blank line after the data is what flushes it."""
        return f"data: {json.dumps(payload, default=str)}\n\n"

    def events():
        try:
            for event in stream_reply(session, message, client=client):
                yield sse(event)
        except LLMError as exc:
            yield sse({"type": "error", "message": str(exc)})
        except Exception as exc:  # noqa: BLE001 - the stream must always close
            yield sse({"type": "error", "message": f"{type(exc).__name__}: {exc}"})

    return StreamingResponse(
        events(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.post("/api/chat/reset")
def chat_reset(session_id: str = Body(..., embed=True)) -> dict:
    """Forget a conversation."""
    return {"reset": SESSIONS.reset(session_id)}


# --------------------------------------------------------------------------
# Human annotation (for the label-reliability check)
# --------------------------------------------------------------------------


def _annotation_store(run: str):
    from ..validation import AnnotationStore

    return AnnotationStore.load(RESULTS_DIR / f"{Path(run).name}.annotations.json")


@app.get("/api/annotations")
def annotations(run: str) -> dict:
    """The human labels saved for a run, plus kappa against the automatic ones."""
    from ..validation import validate_against_human

    store = _annotation_store(run)
    frame = _load(run)["frame"]
    records = frame.to_dict(orient="records") if not frame.empty else []
    agreement = validate_against_human(records, store) if store.labels else {}
    return {"labels": store.labels, "count": len(store), "agreement": agreement}


@app.post("/api/annotate")
def annotate(run: str = Body(...), key: str = Body(...), label: str = Body(...)) -> dict:
    """Save (or clear) one human label, then return the updated kappa."""
    from ..validation import validate_against_human

    store = _annotation_store(run)
    try:
        store.set(key, label)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    store.save()
    frame = _load(run)["frame"]
    records = frame.to_dict(orient="records") if not frame.empty else []
    return {"saved": True, "count": len(store),
            "agreement": validate_against_human(records, store) if store.labels else {}}


# --------------------------------------------------------------------------
# The deeper analyses: battery, mechanistic, regression
# --------------------------------------------------------------------------


def _sidecar(run: str, suffix: str) -> Path:
    return RESULTS_DIR / f"{Path(run).name}.{suffix}"


@app.get("/api/battery")
def battery(run: str) -> dict:
    """The faithfulness battery summary for a run, if it has one."""
    from ..battery_score import battery_summary

    path = _sidecar(run, "battery.jsonl")
    if not path.exists():
        return {"available": False, "run": run}
    rows = [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
    return {"available": True, **_json_safe(battery_summary(rows))}


@app.get("/api/mech")
def mech(run: str) -> dict:
    """Mechanistic log-prob step effects: reasoning steps vs the answer step."""
    path = _sidecar(run, "mech.jsonl")
    if not path.exists():
        return {"available": False, "run": run}
    rows = [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
    scored = [r for r in rows if not r.get("error") and isinstance(r.get("logprob_drop"), (int, float))]
    reasoning = [r["logprob_drop"] for r in scored if not r.get("is_answer_step")]
    answer = [r["logprob_drop"] for r in scored if r.get("is_answer_step")]
    mean = lambda xs: round(sum(xs) / len(xs), 4) if xs else None
    # Per step index, for a small bar chart.
    by_step: dict[int, list[float]] = {}
    for r in scored:
        by_step.setdefault(int(r["step_idx"]), []).append(r["logprob_drop"])
    return {
        "available": True, "model": rows[0].get("model_id") if rows else "",
        "reasoning_mean_drop": mean(reasoning), "reasoning_n": len(reasoning),
        "answer_mean_drop": mean(answer), "answer_n": len(answer),
        "by_step": [{"step": k, "mean_drop": mean(v), "n": len(v)} for k, v in sorted(by_step.items())],
    }


@app.get("/api/regression")
def regression(run: str) -> dict:
    """Logistic regression for P(follows), separating the confounds."""
    from ..validation import label_regression

    frame = _load(run)["frame"]
    if frame.empty:
        return {"error": "no records"}
    return _json_safe(label_regression(frame))


@app.get("/api/patch")
def patch(run: str) -> dict:
    """Activation-patching causal-tracing curve, if the run has one."""
    from ..mech import PatchResult, patch_curve

    path = _sidecar(run, "patch.jsonl")
    if not path.exists():
        return {"available": False, "run": run}
    rows = [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
    results = [PatchResult(**{k: v for k, v in r.items() if k in PatchResult.__dataclass_fields__})
               for r in rows]
    out = patch_curve(results)
    return {"available": True, "model": rows[0].get("model_id") if rows else "", **_json_safe(out)}


@app.get("/api/introspect")
def introspect(run: str) -> dict:
    """Self-knowledge probe summary: detection, false-alarm, fooled-and-blind."""
    from ..introspect import introspect_summary

    path = _sidecar(run, "introspect.jsonl")
    if not path.exists():
        return {"available": False, "run": run}
    rows = [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
    return {"available": True, "per_model": _json_safe(introspect_summary(rows))}


@app.get("/api/probe")
def probe(run: str = "probe") -> dict:
    """The faithfulness benchmark: its manifest, and (if a run exists) the
    tiered scorecard — sensitivity, distractor and control follow, against
    known critical steps."""
    from ..benchmark import build_manifest
    from ..probe_score import probe_summary

    manifest = build_manifest()
    out = {"manifest": _json_safe({
        "name": manifest["name"], "version": manifest["version"],
        "n_items": manifest["n_items"], "by_tier": manifest["by_tier"],
        "by_domain": manifest["by_domain"],
        "fallback_coverage": manifest["fallback_coverage"]["coverage"],
    })}
    path = RESULTS_DIR / (run if run.endswith(".jsonl") else f"{run}.jsonl")
    if not path.exists():
        return {"available": False, **out}
    summary = probe_summary(load_records(path))
    if not summary["per_model"]:
        return {"available": False, **out}
    return {"available": True, **out, **_json_safe(summary)}


@app.get("/api/interactions")
def interactions(run: str) -> dict:
    """Pair interventions: the redundancy a single-step probe cannot see.

    Reads the ``<run>.interactions.jsonl`` sidecar. Empty unless the run has
    had ``python main.py interactions`` pointed at it; the main results file
    is never touched by this.
    """
    from ..interactions import interaction_report, load_interactions

    path = _sidecar(run, "interactions.jsonl")
    if not path.exists():
        return {"available": False, "run": run}
    return _json_safe({"available": True, **interaction_report(load_interactions(path))})


@app.get("/api/tautology")
def tautology(run: str) -> dict:
    """How much of the run's dependency was the answer being restated.

    The positional "final step" proxy against the content-based
    answer-overwritten test. Computed from the records on demand — every input
    it needs is already stored, so this works on runs finished long before the
    test existed.
    """
    from .. import score

    frame = score.records_dataframe(_run_path(run))
    return _json_safe(score.tautology_report(frame))


@app.get("/api/necessity")
def necessity(run: str) -> dict:
    """The ablation arm: which steps the answer actually needed.

    Empty unless the run opted into ``step_deletion``.
    """
    from .. import score

    frame = score.records_dataframe(_run_path(run))
    return _json_safe(score.necessity_report(frame))


@app.get("/api/power")
def power(run: str, p1: float = 0.40, p2: float = 0.25) -> dict:
    """How many questions the headline needs, measured off this run's design.

    Reads cells-per-question and the intra-cluster correlation from the run
    itself, so the sizing answer reflects this design rather than a textbook
    assumption of independent observations.
    """
    from .. import score, stats

    frame = score.records_dataframe(_run_path(run))
    try:
        return _json_safe(stats.power_plan(frame, p1=p1, p2=p2))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/health")
def health() -> dict:
    return {"ok": True, "results_dir": str(RESULTS_DIR)}


# --------------------------------------------------------------------------
# Static front end
# --------------------------------------------------------------------------


@app.get("/")
def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


def serve(host: str = "127.0.0.1", port: int = 8000, reload: bool = False) -> None:
    """Start the dashboard. Called by ``python main.py dashboard``."""
    import uvicorn

    uvicorn.run(
        "stepwise.dashboard.app:app" if reload else app,
        host=host,
        port=port,
        reload=reload,
        log_level="info",
    )
